
public class Driver {

	public static void main(String []args)
	{
		
	System.out.println("Robby should recycle.");

	}
}
	
